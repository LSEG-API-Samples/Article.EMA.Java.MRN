## MRN (Machine Readable News) on Refinitiv Real-Time
#### EMA Java GUI Example

##### Overview
NewsAnalytics__Streaming_GUI is a GUI Viewer that allows to view side-by-side and demonstrates subscribing, decoding and parsing of MRN data RICs: 

* MRN_STORY
* MRN_TRSI
* MRN_TRNA

##### How to Build
We used:

* Oracle Java 8
* Refinitiv Real-Time SDK Java 1.2.1

Download Refinitiv Real-Time SDK Java from https://developers.refinitiv.com/en/api-catalog/elektron/elektron-sdk-java/download
Copy Refinitiv Real-Time SDK Java jar files to \lib\
The file structure should looks like this:
	\bin\
		\com\refinitiv\ema\examples\mrn\
											\AppClient.class
											\MRNConsumer.class
											\MRNFXMain$1.class
											\MRNFXMain.class
	\css\
		\dark.css
		\EikonWebUI.css
		\EikonWebUI-main-Custom.css
		\EikonWebUI-main-Custom-formatted.css
		\Nova_View.css
		\WebUI.css
	\lib\
		\ansipage-3.2.1.0.jar
		\commons-codec-1.4.jar
		\commons-collections-3.2.2.jar
		\commons-configuration-1.10.jar
		\commons-lang-2.6.jar
		\commons-logging-1.1.1.jar
		\commons-logging-1.2.jar
		\ema-3.6.0.0-javadoc.jar
		\ema-3.6.0.0.jar
		\gradle-wrapper.jar
		\httpclient-4.1.2.jar
		\httpclient-cache-4.1.2.jar
		\httpcore-4.1.2.jar
		\httpmime-4.1.2.jar
		\java-json.jar
		\jdacsUpalib.jar
		\mockito-all-1.9.0.jar
		\slf4j-api-1.7.12.jar
		\slf4j-jdk14-1.7.12.jar
		\eta-3.6.0.0.jar
		\etaValueAdd-3.6.0.0.jar
		\etaValueAddCache-3.6.0.0.jar
		\xpp3-1.1.4c.jar
	\src\
		\com\refinitiv\ema\examples\mrn\
											\MRNConsumer.java
											\MRNFXMain.java
	\compile.bat
	\ExampleMRNStreamingGUI.md
	\run.bat

Open a command line and launch "compile.bat"

##### How to Run
Command line arguments:
<ADS_HOST> <ADS_PORT> <MRN_SERVICE> <MRN_USER>
Suggested VM Options:
-Xmx2028m -Xms1024m
 
##### Parsing Approach
* Subscribe to the feed, request domain News Analytics, register for updates
* On an update of type FieldList, look type BUFFER named FRAGMENT, decode:
    * Accumulate all fragments if more than one
    * Concatenate the fragments
    * Unzip using gunzip
    * Pretty-print json
	* Convert RMTES String to UTF-8 String

##### Understanding MRN Data
To better understande the data from any and all MRN streams, one can:
* Stop the stream of data by clicking Stop button
* Copy a piece of data
* Paste it outside the example, into a text file, or onto an excel sheet
* Resume the stream by clicking Resume when ready 
Streaming data from the four RICs (streams) is presented side-by-side so that one can easily:
* Visually compare the data between the streams
* Select the stream that is best suited for a specific use case
