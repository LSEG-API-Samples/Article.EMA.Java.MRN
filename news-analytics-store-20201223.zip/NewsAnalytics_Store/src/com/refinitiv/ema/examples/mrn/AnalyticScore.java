package com.refinitiv.ema.examples.mrn;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.json.JSONException;
import org.json.JSONObject;

@Entity
public class AnalyticScore {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long ID_GENERATED;
	private String id;  //GUID
	private String assetId;
	private String assetName;
	private String assetCodePermId;
	private String assetCodeRIC;
	private String assetCodeN2;  // news category such as "MTAL" meaning "metals" 
	private double sentimentNeutral;
	private double sentimentPositive;
	private double sentimentNegative;
	private double relevance;
	private Date sourceTimestamp;
	
	public AnalyticScore() {}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetCodePermId() {
		return assetCodePermId;
	}

	public void setAssetCodePermId(String assetCodePermId) {
		this.assetCodePermId = assetCodePermId;
	}

	public String getAssetCodeRIC() {
		return assetCodeRIC;
	}

	public void setAssetCodeRIC(String assetCodeRIC) {
		this.assetCodeRIC = assetCodeRIC;
	}

	public String getAssetCodeN2() {
		return assetCodeN2;
	}

	public void setAssetCodeN2(String assetCodeN2) {
		this.assetCodeN2 = assetCodeN2;
	}

	public double getSentimentNeutral() {
		return sentimentNeutral;
	}

	public void setSentimentNeutral(double sentimentNeutral) {
		this.sentimentNeutral = sentimentNeutral;
	}

	public double getSentimentPositive() {
		return sentimentPositive;
	}

	public void setSentimentPositive(double sentimentPositive) {
		this.sentimentPositive = sentimentPositive;
	}

	public double getSentimentNegative() {
		return sentimentNegative;
	}

	public void setSentimentNegative(double sentimentNegative) {
		this.sentimentNegative = sentimentNegative;
	}

	public double getRelevance() {
		return relevance;
	}

	public void setRelevance(double relevance) {
		this.relevance = relevance;
	}

	public Date getSourceTimestamp() {
		return sourceTimestamp;
	}

	public void setSourceTimestamp(Date sourceTimestamp) {
		this.sourceTimestamp = sourceTimestamp;
	}
	
}
