package com.refinitiv.ema.examples.mrn;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.refinitiv.ema.examples.mrn.TRNARating;

public class Persister {
	private static final String PERSISTENCE_UNIT_NAME = "ratings";
	private static EntityManagerFactory factory;

	static {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);	
	}
	
	public static void persistRating(TRNARating rating) {
		EntityManager em = factory.createEntityManager();
		
		// read the existing entries and write to console
/*		Query q = em.createQuery("select t from TRNARating t");
		List<TRNARating> ratingList = q.getResultList();
		        for (TRNARating rating_ : ratingList) {
                System.out.println(rating_);
        }
        System.out.println("Stored ratings: " + ratingList.size());
*/
		// create new Rating
		em.getTransaction().begin();
		em.persist(rating);
		em.getTransaction().commit();

		em.close();
	}
	
	public static void persistScore(AnalyticScore as) {
		EntityManager em = factory.createEntityManager();

		// create new score
		em.getTransaction().begin();
		em.persist(as);
		em.getTransaction().commit();

		em.close();
	}
}
