package com.thomsonreuters.ema.examples.mrn;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Column;

@Entity
public class TRNARating {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long ID_GENERATED;
	private String GUID; //255
	private long TIMACT_MS;
	private String ACTIV_DATE;
	private long FRAG_NUM;
	@Lob 
	@Column(name="FRAGMENT", length=5000)
	private byte[] FRAGMENT;

	public String getGUID() {
		return GUID;
	}
	public void setGUID(String gUID) {
		GUID = gUID;
	}
	public long getTIMACT_MS() {
		return TIMACT_MS;
	}
	public void setTIMACT_MS(long tIMACT_MS) {
		TIMACT_MS = tIMACT_MS;
	}
	public String getACTIV_DATE() {
		return ACTIV_DATE;
	}
	public void setACTIV_DATE(String aCTIV_DATE) {
		ACTIV_DATE = aCTIV_DATE;
	}
	public long getFRAG_NUM() {
		return FRAG_NUM;
	}
	public void setFRAG_NUM(long fRAG_NUM) {
		FRAG_NUM = fRAG_NUM;
	}
	public byte[] getFRAGMENT() {
		return FRAGMENT;
	}
	public void setFRAGMENT(byte[] fRAGMENT) {
		FRAGMENT = fRAGMENT;
	}

}
